// Shared UI helpers (injected as content script / on demand)
(() => {
  if (window.__kwe) return;
  const api = chrome;

  const CSS = `
  :host{all:initial}
  *{box-sizing:border-box;font-family:Inter,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
  .card{background:#fff;color:#0f1f3d;border:1px solid #dfe5ee;border-radius:14px;box-shadow:0 10px 30px rgba(15,31,61,.18);overflow:hidden;font-size:13px;line-height:1.35}
  .hd{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#0f1f3d;color:#fff}
  .hd{cursor:move;user-select:none}.hd b{font-size:13px;flex:1}
  .hd button{background:rgba(255,255,255,.12);color:#fff;border:0;border-radius:6px;padding:3px 8px;font-size:11px;cursor:pointer}
  .hd button:hover{background:rgba(255,255,255,.25)}
  .bd{padding:12px;max-height:70vh;overflow:auto}
  .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
  .st{background:#f5f8fc;border-radius:10px;padding:8px}
  .st small{display:block;color:#66758f;font-size:10px;text-transform:uppercase;letter-spacing:.04em}
  .st strong{font-size:16px}
  .kw{font-weight:600;margin-bottom:8px;word-break:break-word}
  table{width:100%;border-collapse:collapse}
  th{font-size:10px;text-transform:uppercase;color:#66758f;text-align:left;padding:4px 4px;letter-spacing:.04em}
  td{padding:6px 4px;border-top:1px solid #edf1f7;vertical-align:middle}
  td.k{max-width:120px;word-break:break-word;font-size:12px}
  .num{text-align:right;white-space:nowrap}
  .b{display:inline-block;padding:1px 7px;border-radius:99px;font-size:11px;font-weight:600}
  .b.low{background:#dcfce7;color:#166534}.b.medium{background:#fef3c7;color:#92400e}.b.high{background:#fee2e2;color:#991b1b}
  .na{color:#9aa6bb}
  .msg{padding:10px;border-radius:8px;background:#f5f8fc;color:#44546f}
  .err{background:#fee2e2;color:#991b1b}
  .sec{margin:12px 0 4px;font-size:11px;font-weight:700;color:#66758f;text-transform:uppercase;letter-spacing:.05em}
  .ft{padding:8px 12px;border-top:1px solid #edf1f7;font-size:11px;color:#66758f;display:flex;justify-content:space-between}
  .ft a{color:#0b6bcb;text-decoration:none}
  svg.sp{display:block;overflow:visible;cursor:crosshair}
  .tip{position:fixed;z-index:2147483647;pointer-events:none;background:#0f1f3d;color:#fff;border-radius:8px;padding:5px 8px;font-size:11px;white-space:nowrap;display:none}
  .tip b{display:block;font-size:12px}
  `;

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = (n) => (n == null || isNaN(n) ? '—' : Number(n).toLocaleString('en-US'));
  const money = (n) => (n == null || !isFinite(n) || n <= 0 ? '—' : '$' + Number(n).toFixed(2));
  const comp = (c) => {
    if (!c) return '<span class="na">—</span>';
    const k = String(c).toLowerCase();
    return `<span class="b ${esc(k)}">${esc(k.charAt(0).toUpperCase() + k.slice(1))}</span>`;
  };

  // 12-month line graph with hover tooltip (month + searches)
  function spark(m) {
    const v = (m && m.monthlyVolumes) || [];
    if (!m || !m.volume || v.length < 2) return '<span class="na">—</span>';
    const W = 92, H = 26, pad = 2;
    const vals = v.map((p) => Number(p.volume) || 0);
    const max = Math.max(...vals), min = Math.min(...vals);
    const span = max - min || 1;
    const pts = vals.map((x, i) => [pad + (i * (W - 2 * pad)) / (vals.length - 1), pad + (H - 2 * pad) * (1 - (x - min) / span)]);
    const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    const area = `${line} L${pts[pts.length - 1][0].toFixed(1)} ${H} L${pts[0][0].toFixed(1)} ${H} Z`;
    const falling = vals[vals.length - 1] < vals[0];
    const col = falling ? '#f97316' : '#10b981';
    const data = v.map((p) => `${p.label}|${p.volume}`).join(';');
    return `<svg class="sp" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" data-pts="${esc(data)}" data-w="${W}">
      <path d="${area}" fill="${col}" opacity=".12"/>
      <path d="${line}" fill="none" stroke="${col}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>
      <circle class="dot" r="0" cx="0" cy="0" fill="${col}"/>
    </svg>`;
  }

  function attachSparkTips(root) {
    const tip = document.createElement('div');
    tip.className = 'tip';
    root.appendChild(tip);
    root.addEventListener('mousemove', (e) => {
      const svg = e.target.closest && e.target.closest('svg.sp');
      if (!svg) { tip.style.display = 'none'; return; }
      const pts = svg.getAttribute('data-pts').split(';').map((s) => s.split('|'));
      const r = svg.getBoundingClientRect();
      const frac = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      const i = Math.round(frac * (pts.length - 1));
      const vals = pts.map((p) => Number(p[1]));
      const max = Math.max(...vals), min = Math.min(...vals), span = max - min || 1;
      const x = 2 + (i * (r.width - 4)) / (pts.length - 1);
      const y = 2 + (r.height - 4) * (1 - (vals[i] - min) / span);
      const dot = svg.querySelector('.dot');
      dot.setAttribute('cx', x); dot.setAttribute('cy', y); dot.setAttribute('r', 3);
      tip.innerHTML = `<b>${esc(pts[i][0])}</b>${fmt(vals[i])} searches`;
      tip.style.display = 'block';
      tip.style.left = Math.min(window.innerWidth - 140, e.clientX + 12) + 'px';
      tip.style.top = e.clientY + 16 + 'px';
    });
    root.addEventListener('mouseleave', () => { tip.style.display = 'none'; });
    root.addEventListener('mouseout', (e) => {
      const svg = e.target.closest && e.target.closest('svg.sp');
      if (svg) { svg.querySelector('.dot').setAttribute('r', 0); tip.style.display = 'none'; }
    });
  }

  const getSettings = () => new Promise((r) => api.storage.sync.get({ country: 'US', enabled: true }, r));

  const metrics = (keywords, country) =>
    new Promise((res) => {
      try {
        api.runtime.sendMessage({ type: 'metrics', keywords, country }, (r) => {
          if (api.runtime.lastError) res({ ok: false, error: api.runtime.lastError.message });
          else res(r || { ok: false, error: 'No response' });
        });
      } catch (e) {
        res({ ok: false, error: 'Extension was updated. Please reload this page.' });
      }
    });

  function host(id) {
    const old = document.getElementById(id);
    if (old) old.remove();
    const h = document.createElement('div');
    h.id = id;
    h.style.all = 'initial';
    const root = h.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style>`;
    attachSparkTips(root);
    return { h, root };
  }

  const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

  window.__kwe = { esc, fmt, money, comp, spark, getSettings, metrics, host, norm };
})();
