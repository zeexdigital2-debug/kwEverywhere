// KWEverywhere background service worker (MV3)
const API = 'https://kw-backend-chi.vercel.app/api/extension/metrics';
const TTL = 24 * 60 * 60 * 1000;       // 24h local cache per keyword+country
const MAX_PER_REQUEST = 100;
const MAX_CACHE_ENTRIES = 5000;

const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

function pickList(d, depth = 0) {
  if (Array.isArray(d)) return d;
  if (!d || typeof d !== 'object' || depth > 2) return [];
  for (const k of ['results', 'keywords', 'data', 'items']) {
    const x = pickList(d[k], depth + 1);
    if (x.length) return x;
  }
  return [];
}

function normalize(it) {
  const comp = it.competition ? String(it.competition).toLowerCase() : null;
  return {
    keyword: norm(it.keyword || it.text),
    volume: Number(it.volume ?? it.avgMonthlySearches ?? 0) || 0,
    competition: comp,
    cpc: Number(it.cpc ?? it.averageCpc ?? 0) || 0,
    opportunity: it.opportunity ?? null,
    monthlyVolumes: Array.isArray(it.monthlyVolumes) ? it.monthlyVolumes : [],
  };
}

async function loadCache() {
  const { kwcache } = await chrome.storage.local.get('kwcache');
  return kwcache || {};
}

async function saveCache(cache) {
  const keys = Object.keys(cache);
  if (keys.length > MAX_CACHE_ENTRIES) {
    keys.sort((a, b) => cache[a].t - cache[b].t)
      .slice(0, keys.length - MAX_CACHE_ENTRIES)
      .forEach((k) => delete cache[k]);
  }
  await chrome.storage.local.set({ kwcache: cache });
}

async function getMetrics(keywords, country) {
  const list = [...new Set(keywords.map(norm).filter(Boolean))].slice(0, MAX_PER_REQUEST);
  const cache = await loadCache();
  const now = Date.now();
  const out = {};
  const missing = [];
  for (const kw of list) {
    const hit = cache[`${country}|${kw}`];
    if (hit && now - hit.t < TTL) out[kw] = hit.v;
    else missing.push(kw);
  }
  if (missing.length) {
    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ keywords: missing, country }),
    });
    let data = null;
    try { data = await res.json(); } catch (e) { /* ignore */ }
    if (!res.ok) {
      throw new Error((data && (data.error || data.message)) || `Server error (${res.status})`);
    }
    const byKw = {};
    for (const it of pickList(data)) {
      const m = normalize(it);
      if (m.keyword) byKw[m.keyword] = m;
    }
    for (const kw of missing) {
      const m = byKw[kw] || { keyword: kw, volume: 0, competition: null, cpc: 0, opportunity: null, monthlyVolumes: [] };
      out[kw] = m;
      cache[`${country}|${kw}`] = { t: now, v: m };
    }
    await saveCache(cache);
  }
  return out;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'metrics') {
    getMetrics(msg.keywords || [], msg.country || 'US')
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: e.message || 'Request failed' }));
    return true; // async
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'kwe-lookup',
      title: 'KWEverywhere: keyword data for "%s"',
      contexts: ['selection'],
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'kwe-lookup' || !tab || !tab.id) return;
  const kw = (info.selectionText || '').trim();
  if (!kw) return;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['ui.js', 'selection.js'] });
    await chrome.tabs.sendMessage(tab.id, { type: 'showCard', keyword: kw });
  } catch (e) {
    // Restricted pages (chrome://, web store) cannot be scripted
  }
});
