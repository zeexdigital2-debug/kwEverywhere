// Google search results: top horizontal bar (main keyword) + right sidebar (related keywords)
(async () => {
  const K = window.__kwe;
  if (!K) return;
  const s = await K.getSettings();
  if (!s.enabled) return;

  const q = K.norm(new URLSearchParams(location.search).get('q') || '');
  if (!q || q.length > 80 || /\b(site|cache|related|inurl|intitle|filetype):/i.test(q) || q.split(' ').length > 10) return;

  const COUNTRIES = [['US', 'United States'], ['GB', 'United Kingdom'], ['CA', 'Canada'], ['AU', 'Australia'], ['PK', 'Pakistan'],
    ['IN', 'India'], ['AE', 'UAE'], ['QA', 'Qatar'], ['SA', 'Saudi Arabia'], ['DE', 'Germany'], ['FR', 'France'], ['ES', 'Spain'], ['IT', 'Italy']];

  const EXTRA_CSS = `
    .bar{display:flex;align-items:center;gap:18px;flex-wrap:wrap;background:#0f1f3d;color:#fff;padding:8px 16px;font-size:13px;border-bottom:1px solid #1d3461}
    .bar .brand{font-weight:800;letter-spacing:.01em}
    .bar .kwt{font-weight:600;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:rgba(255,255,255,.1);padding:3px 10px;border-radius:99px}
    .bar .m{display:flex;flex-direction:column;line-height:1.15}
    .bar .m small{font-size:9px;text-transform:uppercase;letter-spacing:.06em;color:#9fb2d4}
    .bar .m strong{font-size:15px}
    .bar .sp{margin-top:0}
    .bar .push{margin-left:auto;display:flex;align-items:center;gap:8px}
    .bar select{background:rgba(255,255,255,.12);color:#fff;border:0;border-radius:6px;padding:4px 6px;font-size:12px}
    .bar select option{color:#0f1f3d}
    .bar button{background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
    .bar button:hover{background:rgba(255,255,255,.28)}
    .bar .b.low{background:#bbf7d0}.bar .b.medium{background:#fde68a}.bar .b.high{background:#fecaca}
    .bar .na{color:#9fb2d4}
    .bar .msg{background:transparent;color:#cfe0ff;padding:0}
    .bar .err{color:#fecaca;background:transparent}
    .side{margin:0 0 16px}
    .side .bd{max-height:none}
  `;

  // ---- mount points -------------------------------------------------------
  const bar = K.host('kwe-bar');
  bar.root.querySelector('style').textContent += EXTRA_CSS;
  bar.h.style.cssText = 'all:initial;display:block;width:100%;position:relative;z-index:2147483000';
  const barBox = document.createElement('div');
  bar.root.appendChild(barBox);
  document.body.insertBefore(bar.h, document.body.firstChild);

  const side = K.host('kwe-side');
  side.root.querySelector('style').textContent += EXTRA_CSS;
  const sideBox = document.createElement('div');
  side.root.appendChild(sideBox);

  function mountSide() {
    const rhs = document.querySelector('#rhs');
    if (side.h.isConnected && (!rhs || side.h.parentElement === rhs)) return; // already placed
    side.h.style.cssText = 'all:initial;display:block;width:100%';
    if (rhs) {
      const old = document.getElementById('kwe-rhs'); if (old) old.remove();
      rhs.insertBefore(side.h, rhs.firstChild); return;
    }
    const rcnt = document.querySelector('#rcnt');
    const center = document.querySelector('#center_col');
    if (rcnt && center) {
      const col = document.createElement('div');
      col.id = 'kwe-rhs';
      col.style.cssText = 'width:369px;flex:none;margin-left:60px;padding-top:8px';
      col.appendChild(side.h);
      rcnt.appendChild(col);
      const cs = getComputedStyle(rcnt);
      const beside = col.getBoundingClientRect().left >= center.getBoundingClientRect().right - 5;
      if (cs.display.indexOf('flex') === -1 && !beside) {
        // Layout is not side-by-side: fall back to a fixed column on the right edge
        col.style.cssText = 'position:fixed;top:150px;right:14px;width:369px;max-height:75vh;overflow:auto;z-index:2147483000';
      }
      return;
    }
    side.h.style.cssText = 'all:initial;position:fixed;top:150px;right:14px;width:369px;z-index:2147483000';
    document.body.appendChild(side.h);
  }
  mountSide();

  // ---- state & render ------------------------------------------------------
  let state = { status: 'loading', main: null, related: [], error: '' };
  let country = s.country;

  function collectRelated() {
    const out = [];
    const seen = new Set([q]);
    document.querySelectorAll('#botstuff a[href*="/search?"], #bres a[href*="/search?"], #rhs a[href*="/search?"]').forEach((a) => {
      if (a.closest('#kwe-side, #kwe-bar')) return;
      let kw = '';
      try { kw = K.norm(new URL(a.href, location.href).searchParams.get('q') || ''); } catch (e) { return; }
      if (!kw || kw.length > 80 || kw.split(' ').length > 10 || seen.has(kw)) return;
      seen.add(kw);
      out.push(kw);
    });
    return out.slice(0, 20);
  }

  function relatedRows(list) {
    return list.map(({ keyword, m }) => `
      <tr><td class="k">${K.esc(keyword)}</td>
      <td class="num">${m && m.volume ? K.fmt(m.volume) : '<span class="na">—</span>'}</td>
      <td class="num">${m && m.volume ? K.money(m.cpc) : '<span class="na">—</span>'}</td>
      <td>${m && m.volume ? K.comp(m.competition) : '<span class="na">—</span>'}</td>
      <td>${K.spark(m)}</td></tr>`).join('');
  }

  function render() {
    const opts = COUNTRIES.map(([c, n]) => `<option value="${c}"${c === country ? ' selected' : ''}>${n}</option>`).join('');
    let mid = '';
    if (state.status === 'loading') mid = '<span class="msg">Loading keyword data…</span>';
    else if (state.status === 'error') mid = `<span class="msg err">${K.esc(state.error)}</span>`;
    else {
      const m = state.main.m;
      const has = !!m.volume;
      mid = `<div class="m"><small>Volume</small><strong>${has ? K.fmt(m.volume) : '—'}</strong></div>
        <div class="m"><small>CPC</small><strong>${has ? K.money(m.cpc) : '—'}</strong></div>
        <div class="m"><small>Competition</small><strong>${has ? K.comp(m.competition) : '—'}</strong></div>
        <div class="m"><small>12 months</small>${K.spark(m)}</div>`;
    }
    barBox.innerHTML = `<div class="bar">
      <span class="brand">KWEverywhere</span>
      ${mid}
      <div class="push">
        <select data-a="country" title="Country">${opts}</select>
        <button data-a="close" title="Hide">✕</button>
      </div></div>`;

    if (state.status === 'ok') {
      sideBox.innerHTML = `<div class="card side"><div class="hd"><b>Related keywords (${state.related.length})</b>
        <button data-a="copy">Copy</button><button data-a="csv">Export CSV</button></div>
        <div class="bd">${state.related.length
          ? `<table><thead><tr><th>Keyword</th><th class="num">Vol</th><th class="num">CPC</th><th>Comp</th><th>12M</th></tr></thead>
        <tbody>${relatedRows(state.related)}</tbody></table>`
          : '<div class="msg">No related keywords found on this page.</div>'}</div>
        <div class="ft"><span>Free keyword data</span><a href="https://www.kweverywhere.com" target="_blank" rel="noopener">kweverywhere.com</a></div></div>`;
    } else if (state.status === 'loading') {
      sideBox.innerHTML = '<div class="card side"><div class="hd"><b>Related keywords</b></div><div class="bd"><div class="msg">Loading…</div></div></div>';
    } else {
      sideBox.innerHTML = '';
    }
  }

  bar.root.addEventListener('click', (e) => {
    const a = e.target.getAttribute && e.target.getAttribute('data-a');
    if (a === 'close') { bar.h.remove(); side.h.remove(); const c = document.getElementById('kwe-rhs'); if (c) c.remove(); }
  });
  function rowsForExport() {
    return [state.main, ...state.related].map((r) => [r.keyword, r.m.volume || 0, (r.m.cpc || 0).toFixed(2), r.m.competition || '']);
  }
  side.root.addEventListener('click', (e) => {
    const a = e.target.getAttribute && e.target.getAttribute('data-a');
    if (state.status !== 'ok') return;
    if (a === 'copy') {
      const tsv = ['Keyword\tVolume\tCPC (USD)\tCompetition'].concat(rowsForExport().map((r) => r.join('\t'))).join('\n');
      navigator.clipboard.writeText(tsv).then(() => {
        e.target.textContent = 'Copied';
        setTimeout(() => (e.target.textContent = 'Copy'), 1200);
      });
    }
    if (a === 'csv') {
      const q2 = (v) => '"' + String(v).replace(/"/g, '""') + '"';
      const csv = '\ufeff' + [['Keyword', 'Volume', 'CPC (USD)', 'Competition', 'Country']]
        .concat(rowsForExport().map((r) => r.concat([country]))).map((r) => r.map(q2).join(',')).join('\r\n');
      const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
      const el = document.createElement('a');
      el.href = url;
      el.download = `kweverywhere-${q.replace(/[^a-z0-9]+/gi, '-').slice(0, 40)}-${country}.csv`;
      document.body.appendChild(el); el.click(); el.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }
  });
  bar.root.addEventListener('change', (e) => {
    if (e.target.getAttribute('data-a') === 'country') {
      country = e.target.value;
      chrome.storage.sync.set({ country });
      lastKey = '';
      state = { status: 'loading', main: null, related: [], error: '' };
      render();
      run();
    }
  });

  let lastKey = '';
  async function run() {
    const related = collectRelated();
    const key = country + '|' + related.join('|');
    if (key === lastKey && state.status === 'ok') return;
    lastKey = key;
    const res = await K.metrics([q, ...related], country);
    if (!res.ok) { state = { status: 'error', error: res.error || 'Could not load data', main: null, related: [] }; render(); return; }
    const d = res.data || {};
    const blank = (k) => ({ keyword: k, volume: 0, competition: null, cpc: 0, monthlyVolumes: [] });
    state = {
      status: 'ok', error: '',
      main: { keyword: q, m: d[q] || blank(q) },
      related: related.map((k) => ({ keyword: k, m: d[k] || blank(k) })),
    };
    mountSide(); // #rhs may appear after load
    render();
  }

  render();
  setTimeout(run, 700);
  setTimeout(run, 3500); // lazily loaded related searches (cache makes repeats free)
})();
