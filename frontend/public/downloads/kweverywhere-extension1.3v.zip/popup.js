const K = window.__kwe;
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get({ country: 'US', enabled: true }, (s) => {
  $('country').value = s.country;
  $('enabled').checked = s.enabled;
});
$('country').onchange = () => chrome.storage.sync.set({ country: $('country').value });
$('enabled').onchange = () => chrome.storage.sync.set({ enabled: $('enabled').checked });

async function lookup() {
  const kw = K.norm($('kw').value).slice(0, 80);
  if (!kw) return;
  $('out').innerHTML = '<div class="msg">Loading…</div>';
  const res = await K.metrics([kw], $('country').value);
  if (!res.ok) { $('out').innerHTML = `<div class="msg err">${K.esc(res.error)}</div>`; return; }
  const m = (res.data || {})[kw] || { volume: 0 };
  $('out').innerHTML = m.volume
    ? `<div class="stats">
        <div class="st"><small>Volume</small><strong>${K.fmt(m.volume)}</strong></div>
        <div class="st"><small>CPC</small><strong>${K.money(m.cpc)}</strong></div>
        <div class="st"><small>Competition</small><strong>${K.comp(m.competition)}</strong></div></div>`
    : '<div class="msg">No Google data for this keyword.</div>';
}
$('go').onclick = lookup;
$('kw').addEventListener('keydown', (e) => { if (e.key === 'Enter') lookup(); });
