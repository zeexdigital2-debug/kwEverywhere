// Right-click a selected keyword -> small card with its data
(() => {
  if (window.__kweSelectionReady) return;
  window.__kweSelectionReady = true;
  const K = window.__kwe;

  async function show(keyword) {
    const kw = K.norm(keyword).slice(0, 80);
    if (!kw) return;
    let rect = null;
    try { rect = window.getSelection().getRangeAt(0).getBoundingClientRect(); } catch (e) { /* none */ }
    const s = await K.getSettings();
    const { h, root } = K.host('kwe-card');
    const box = document.createElement('div');
    const left = rect ? Math.max(8, Math.min(window.innerWidth - 320, rect.left)) : 20;
    const top = rect ? Math.min(window.innerHeight - 200, rect.bottom + 8) : 20;
    box.style.cssText = `position:fixed;left:${left}px;top:${top}px;width:300px;z-index:2147483647`;
    root.appendChild(box);
    document.documentElement.appendChild(h);

    const close = () => { h.remove(); document.removeEventListener('keydown', onKey, true); document.removeEventListener('mousedown', onDown, true); };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    const onDown = (e) => { if (!e.composedPath().includes(h)) close(); };
    document.addEventListener('keydown', onKey, true);
    setTimeout(() => document.addEventListener('mousedown', onDown, true), 50);

    const draw = (inner) => {
      box.innerHTML = `<div class="card"><div class="hd"><b>KWEverywhere · ${K.esc(s.country)}</b><button data-x>✕</button></div>
        <div class="bd">${inner}</div></div>`;
      box.querySelector('[data-x]').onclick = close;
    };
    draw('<div class="msg">Loading keyword data…</div>');
    const res = await K.metrics([kw], s.country);
    if (!res.ok) { draw(`<div class="msg err">${K.esc(res.error || 'Could not load data')}</div>`); return; }
    const m = (res.data || {})[kw] || { volume: 0 };
    draw(`<div class="kw">${K.esc(kw)}</div>
      <div class="stats">
        <div class="st"><small>Volume</small><strong>${m.volume ? K.fmt(m.volume) : '—'}</strong></div>
        <div class="st"><small>CPC</small><strong>${m.volume ? K.money(m.cpc) : '—'}</strong></div>
        <div class="st"><small>Competition</small><strong>${m.volume ? K.comp(m.competition) : '—'}</strong></div>
      </div><div>${K.spark(m)}</div>
      ${m.volume ? '' : '<div class="msg" style="margin-top:8px">No Google data for this keyword.</div>'}`);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'showCard') show(msg.keyword);
  });
})();
